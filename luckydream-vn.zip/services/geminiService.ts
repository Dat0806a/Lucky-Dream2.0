
import { GoogleGenAI, Type } from "@google/genai";
import { Garment, GeminiOutfitResponse, TravelPlan } from "../types";

// Initialize Gemini API client with API key from environment
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const cleanBase64 = (base64: string) => {
  if (base64.includes(',')) {
    return base64.split(',')[1];
  }
  return base64;
};

/**
 * Hàm trích xuất JSON từ văn bản phản hồi của AI
 * Đôi khi AI trả về text kèm theo khối ```json ... ``` hoặc văn bản giải thích.
 */
const extractJson = (text: string) => {
  try {
    // Thử parse trực tiếp trước
    return JSON.parse(text);
  } catch (e) {
    // Nếu lỗi, tìm khối JSON trong Markdown
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[0]);
      } catch (innerE) {
        console.error("Không thể parse khối JSON tìm thấy:", innerE);
      }
    }
    return null;
  }
};

export const generateOutfitsFromImages = async (
  tops: Garment[],
  bottoms: Garment[]
): Promise<GeminiOutfitResponse | null> => {
  try {
    const ai = getAI();
    
    // Convert top garments to API-compatible parts
    const topParts = tops.map((g, index) => ([
      { text: `Áo số ${index}:` },
      {
        inlineData: {
          data: cleanBase64(g.image),
          mimeType: "image/png",
        }
      }
    ])).flat();

    // Convert bottom garments to API-compatible parts
    const bottomParts = bottoms.map((g, index) => ([
      { text: `Quần/Váy số ${index}:` },
      {
        inlineData: {
          data: cleanBase64(g.image),
          mimeType: "image/png",
        }
      }
    ])).flat();

    const prompt = `
      Bạn là một chuyên gia thời trang cao cấp người Việt Nam. 
      Nhiệm vụ: Phân tích danh sách áo và quần/váy tôi đã gửi. 
      Hãy chọn ra 3 bộ phối đồ (outfits) ĐẸP NHẤT và HỢP THỜI TRANG NHẤT.
      Trả về JSON chính xác theo cấu trúc yêu cầu.
    `;

    // Always use responseSchema when responseMimeType is application/json for guaranteed structure
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            ...topParts,
            ...bottomParts,
            { text: prompt }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            outfits: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  topIndex: { type: Type.INTEGER },
                  bottomIndex: { type: Type.INTEGER },
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  personality: { type: Type.STRING },
                  locations: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ["topIndex", "bottomIndex", "name", "description", "personality", "locations"]
              }
            }
          },
          required: ["outfits"]
        }
      }
    });

    const parsed = extractJson(response.text || "{}");
    if (!parsed) return null;
    
    // Validation to ensure AI indices are within range of provided garments
    const safeOutfits = (parsed.outfits || []).filter((o: any) => 
      o.topIndex >= 0 && o.topIndex < tops.length && 
      o.bottomIndex >= 0 && o.bottomIndex < bottoms.length
    );

    return { outfits: safeOutfits };
  } catch (error) {
    console.error("Lỗi phân tích Gemini:", error);
    return null;
  }
};

export const generateTravelPlan = async (
  city: string,
  outfitDescription: string,
  vibe: string
): Promise<{plan: TravelPlan, sources: any[]} | null> => {
  try {
    const ai = getAI();
    // Use gemini-3-pro-preview for complex reasoning and search tasks
    const prompt = `
      Tôi đang ở thành phố "${city}" tại Việt Nam. Tôi đang mặc một bộ đồ: "${outfitDescription}" với vibe "${vibe}".
      Hãy sử dụng Google Search để tìm và đề xuất hành trình du lịch THỰC TẾ, CẬP NHẬT tại ${city}.
      
      YÊU CẦU TRẢ VỀ CHỈ DUY NHẤT KHỐI JSON (KHÔNG CÓ CHỮ GIẢI THÍCH Ở NGOÀI) theo cấu trúc:
      {
        "luxury": [{"name": "Tên", "address": "Địa chỉ", "description": "Lý do chọn", "specialtyFood": "Món nên thử", "foodAddress": "Nơi ăn"}],
        "local": [{"name": "Tên", "address": "Địa chỉ", "description": "Tại sao nổi tiếng", "specialtyFood": "Món ngon", "foodAddress": "Địa chỉ quán"}],
        "transportation": [{"service": "Tên dịch vụ", "description": "Ưu điểm", "contactInfo": "Thông tin liên hệ/app"}],
        "culturalNote": "Lưu ý văn hóa ngắn gọn"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    const parsed = extractJson(response.text || "{}");
    if (!parsed) return null;

    return {
      plan: parsed as TravelPlan,
      // Always extract and return grounding sources for citations
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Lỗi tạo Travel Plan:", error);
    return null;
  }
};
